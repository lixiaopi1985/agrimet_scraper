"""used to check if data existed in database already
"""


def duplicate_checker(tuple1,list_all):
    return tuple1 in list_all



