agrimetscraper crawls AgriMet weather data and summarise for later data usage.
