"""Writing data frame to database
"""

import sqlite3
import pandas as pd
import sys
import re


def coltypes(df):
    """Decides column types to store for database
    
    Arguments:
        df {pandas dataframe} -- [pandas dataframe]
    """
    cols = df.columns.tolist()

    floattypes = re.compile("^[Ll]atitude$|^LATITUDE$|^[Ll]ongitude$|^LONGITUDE$|^ELEVATION.*?$|^[Ee]levation.*?$|^[A-Za-z]{2,4}$|^[A-Za-z]{2}[0-9]{1}$")


    objectypes = re.compile("^[Dd]ate.*?$|^DATE.*?$|[Yy]ear.*?$|^YEAR.*?$|^[Tt]ime$|^[Dd]ay.*?$|^[Mm]onth.*?$|^MONTH.*?$|[Ss]ite.*|SITE.*|^[Dd]escription.*?$|^DESCRIPTION$")


    coltypes = {}
    for i in cols:
        if floattypes.search(i):
            coltypes[i] = 'real'
        elif objectypes.search(i):
            coltypes[i] = 'text'

    return coltypes


def dataframe_to_sql(df, dbpath, dbtable, logger):
    """
    insert each row into defined database and datatable

    df {pandas dataframe}
    dbpath {database path}
    dbtable {table name}
    """


    coltype = coltypes(df) # dictionary
    colname = df.columns.tolist()
    placeholder_col = ",".join(["?"]*len(colname))
    # (col1 TEXT, col2 FLOAT)
    col_tuple = ",".join([ " ".join([coltype[i], i]) for i in colname ])
    createtable = f"""CREATE TABLE IF NOT EXISTS {dbtable} ({col_tuple});"""



    try:
        conn = sqlite3.connect(dbpath)
    except sqlite3.DatabaseError as dbE:
        print(dbE)
        sys.exit(1)

    cur = conn.cursor()
    cur.execute(createtable, col_tuple)

    # fetch data
    fetchsql = f"""SELECT * FROM {dbtable}"""
    existed = cur.execute(fetchsql)

    # insert data
    insertsql = f"""INSERT INTO {dbtable} VALUES ({placeholder_col})"""
    conn.commit()

    for i in range(len(df)):

        row = tuple(df.loc[i, :])

        if not row in existed:
            cur.execute(insertsql, row)
            conn.commit()

        else:
            logger.info(f"EXISTED: row data trying to insert is already in {dbtable}")
    
    logger.info(f"Completed: row data insertion completed in {dbtable}")


# def sql_to_dataframe(dbpath, dbtable, sqlcommand, logger):

#     try:
#         conn = sqlite3.connect(dbpath)
#     except sqlite3.DatabaseError as dbE:
#         print(dbE)
#         sys.exit(1)

#     outdf = pd.read_sql_query(sqlcommand, conn)
#     outdf.dropna(inplace=True)





