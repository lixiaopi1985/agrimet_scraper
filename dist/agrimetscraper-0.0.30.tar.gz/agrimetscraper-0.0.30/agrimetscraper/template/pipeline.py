#!/usr/bin/env python

import sys
import sqlite3
from agrimetscraper.coretools.crawler import Crawler
from agrimetscraper.coretools.dataprocess import dataproc
from agrimetscraper.coretools.urlbuilder import Urlassembly
from agrimetscraper.utils.dbwrite import dataframe_to_sql
from agrimetscraper.utils.mylogger import Setlog
from agrimetscraper.utils.configreader import Configtuner



# look for config file
def agrimetscrape_pipeline(cfg_path, baseurl_section, dbtable):


    logger = Setlog(cfg_path, "Agrimetscraper_Pipeline")
    config = Configtuner(cfg_path)

    # dbbase path
    dbpath = config.getconfig("DB_SETTINGS", "database_path")

    # look for what url link: daily or instant
    baseurl = config.getconfig(baseurl_section, "baseurl")
    params_text = config.getconfig(baseurl_section, "weather_parameters")
    linkformat = config.getconfig(baseurl_section, "format")
    startdate = config.getconfig(baseurl_section, "start")
    enddate = config.getconfig(baseurl_section, "end")
    backdays = config.getconfig(baseurl_section, "back")
    limit = int(config.getconfig(baseurl_section, "limit"))


    # station info
    states = config.getconfig("STATION_SETTINGS", "states")
    try:
        logger.info("Pipeline info: connect to station information")
        conn = sqlite3.connect(dbpath)
    except:
        logger.exception("Pipeline Error: connection to database during pipeline")
        sys.exit(1)

    cur = conn.cursor()
    site_sql = f"SELECT siteid FROM StationInfo WHERE state in ({states});"
    try:
        cur.execute(site_sql)
    except:
        logger.exception("Pipeline Error: an error occurred when getting site ids from database")
        print("Pipeline Error: an error occurred when getting site ids from database")
        sys.exit(1)

    sites = [ i[0] for i in cur.fetchall()]
    params = params_text.split(",")

    # url assembly
    try:
        logger.info("Pipeline Info: url assembly")
        urlassem = Urlassembly(sites, params, baseurl, start=startdate, end=enddate, back=backdays)
        urls = urlassem.asemblyURL(logger)
    except:
        logger.exception("Pipeline Error: url assembly error")
        print("Pipeline Error: url assembly error")
        sys.exit(1)
        

    # crawl
    try:
        
        scraper = Crawler(urls)
        response_text = scraper.startcrawl(logger)
        urlformat = scraper.geturlformat()
        logger.info(f"Pipeline Info: start crawler : status : {scraper.checkstatus}")


    except:
        logger.exception("Pipeline Error: crawler error")
        print("Pipeline Error: crawler error")
        sys.exit(1)


    # process data
    try:
        logger.info("Pipeline Info: process crawled data")
        df = dataproc(response_text, urlformat)
    except:
        logger.exception("Pipeline Error: process crawled data error")
        print("Pipeline Error: process crawled data error")
        sys.exit(1)


    # write to data base
    try:
        logger.info("Pipeline Info: write data into database")
        dataframe_to_sql(df, dbpath, dbtable, logger)
    except:
        logger.exception("Pipeline Error: write data to database error")


    logger.info("ipeline Info: Completed current crawling request")
    print("Completed current crawling request")

if __name__ == "__main__":
    # parse throught flags -u -n, see runproject for details
    cfg_path = sys.argv[1]
    section = sys.argv[2]
    dbtable = sys.argv[3]

    agrimetscrape_pipeline(cfg_path, section, dbtable)

