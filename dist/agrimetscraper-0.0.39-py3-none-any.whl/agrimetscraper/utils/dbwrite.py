"""Writing data frame to database
"""

import sqlite3
import pandas as pd
import sys
import re


def coltypes(df):
    """Decides column types to store for database
    
    Arguments:
        df {pandas dataframe} -- [pandas dataframe]
    """
    cols = df.columns.tolist()

    floattypes = re.compile(r"^[Ll]atitude$|^LATITUDE$|^[Ll]ongitude$|^LONGITUDE$|^ELEVATION.*?$|^[Ee]levation.*?$|^[A-Za-z]{2,4}$|^[A-Za-z]{2}[0-9]{1}$")


    objectypes = re.compile(r"^[Dd]ate.*?$|^DATE.*?$|[Yy]ear.*?$|^YEAR.*?$|^[Tt]ime$|^[Dd]ay.*?$|^[Mm]onth.*?$|^MONTH.*?$|[Ss]ite.*|SITE.*|^[Dd]escription.*?$|^DESCRIPTION$")


    coltypes = {}
    for i in cols:
        if floattypes.search(i):
            coltypes[i] = 'real'
        elif objectypes.search(i):
            coltypes[i] = 'text'

    return coltypes


def dataframe_to_sql(df, dbpath, dbtable, logger):
    """
    insert each row into defined database and datatable

    df {pandas dataframe}
    dbpath {database path}
    dbtable {table name}
    """


    coltype = coltypes(df) # dictionary
    colname = df.columns.tolist()
    placeholder_col = ",".join(["?"]*len(colname))
    # (col1 TEXT, col2 FLOAT)
    # add primary keys datetime and  siteid
    datepattern = re.compile(r"^[Dd]ate.*?$|^DATE.*?$")
    sitepattern = re.compile(r"^[Ss]ite.*?$|^SITE.*?$")

    datecol = "".join([ i.group(0) for i in colname if datepattern.search(i)])
    sitecol = "".join([ i.group(0) for i in colname if sitepattern.search(i)])
    

    primary_keys = f"PRIMARY KEY({datecol, sitecol})"
    col_tuple = ",".join([ " ".join([coltype[i], i]) for i in colname ])
    createtable = f"""CREATE TABLE IF NOT EXISTS {dbtable} ({col_tuple}, {primary_keys});"""



    try:
        conn = sqlite3.connect(dbpath)
    except sqlite3.DatabaseError as dbE:
        print(dbE)
        sys.exit(1)

    cur = conn.cursor()
    cur.execute(createtable)

    # fetch data
    # fetchsql = f"""SELECT * FROM {dbtable}"""
    # existed = cur.execute(fetchsql)

    # insert data
    insertsql = f"""INSERT IGNORE INTO {dbtable} VALUES ({placeholder_col})"""
    conn.commit()

    for i in range(len(df)):

        row = tuple(df.loc[i, :])

        # if not row in existed:
        #     cur.execute(insertsql, row)
        #     conn.commit()
        try:
            cur.execute(insertsql, row)
            conn.commit()
        except:
            logger.exception("Error: insert into data table", exc_info=True)
            sys.exit(1)
    
    logger.info(f"Completed: row data insertion completed in {dbtable}")


# def sql_to_dataframe(dbpath, dbtable, sqlcommand, logger):

#     try:
#         conn = sqlite3.connect(dbpath)
#     except sqlite3.DatabaseError as dbE:
#         print(dbE)
#         sys.exit(1)

#     outdf = pd.read_sql_query(sqlcommand, conn)
#     outdf.dropna(inplace=True)





