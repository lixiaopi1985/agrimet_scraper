from pymongo import MongoClient

def get_db(tbname, port=27017):
    client = MongoClient(f"mongodb://127.0.0.1:{port}/")
    db = client[tbname]
    return db


