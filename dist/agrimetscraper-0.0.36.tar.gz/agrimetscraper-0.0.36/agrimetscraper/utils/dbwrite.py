"""Writing data frame to database
"""

import sqlite3
import pandas as pd
import sys



def dataframe_to_sql(df, dbpath, dbtable, logger):
    """
    insert each row into defined database and datatable

    df {pandas dataframe}
    dbpath {database path}
    dbtable {table name}
    """

    colname = df.columns.tolist()
    placeholder = ",".join(["?"]*len(colname))
    createtable = f"""CREATE TABLE IF NOT EXISTS {dbtable} ({colname});"""

    try:
        conn = sqlite3.connect(dbpath)
    except sqlite3.DatabaseError as dbE:
        print(dbE)
        sys.exit(1)

    cur = conn.cursor()
    cur.execute(createtable)

    # fetch data
    fetchsql = f"""SELECT * FROM {dbtable}"""
    existed = cur.execute(fetchsql)

    # insert data
    insertsql = f"""INSERT INTO {dbtable} ({placeholder})"""

    for i in range(len(df)):

        row = tuple(df.loc[i, :])

        if not row in existed:
            cur.execute(insertsql, row)
            conn.commit()

        else:
            logger.info(f"EXISTED: row data trying to insert is already in {dbtable}")
    
    logger.info(f"Completed: row data insertion completed in {dbtable}")


# def sql_to_dataframe(dbpath, dbtable, sqlcommand, logger):

#     try:
#         conn = sqlite3.connect(dbpath)
#     except sqlite3.DatabaseError as dbE:
#         print(dbE)
#         sys.exit(1)

#     outdf = pd.read_sql_query(sqlcommand, conn)
#     outdf.dropna(inplace=True)





