from pymongo import MongoClient

def get_db(tbname, port=27017):
    client = MongoClient("localhost", port)
    db = client.tbname
    return db


